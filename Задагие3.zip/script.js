Vue.component('modal', {
    template: '#auth_template'
})

BX.Vue.create({
    el: '#auth_form',
    data: {
        showModal: false
    }
})

